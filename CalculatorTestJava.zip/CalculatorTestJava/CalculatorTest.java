import org.junit.Test;
import static org.junit.Assert.*;

public class CalculatorTest {

    @Test
    public void testSimpleAddition() {
        assertEquals("9.0", Calculator.Run("4+5"));
    }

    @Test
    public void testPriorityOperations() {
        assertEquals("27.0", Calculator.Run("10+5*4-3"));
    }

    @Test
    public void testErrorHandling() {
        assertEquals("ERROR", Calculator.Run("10+/5"));
    }

    @Test
    public void testDividebyNull() {
        assertEquals("ERROR", Calculator.Run("10/0));
    }
