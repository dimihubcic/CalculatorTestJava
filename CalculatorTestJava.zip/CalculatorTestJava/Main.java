public class Main {
    public static void main(String[] args) {
        String izraz = "10+5*4-3";
        String rezultat = Calculator.Run(izraz);
        System.out.println("Rezultat: " + rezultat);
    }
}
