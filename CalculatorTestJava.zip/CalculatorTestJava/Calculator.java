import java.util.List;
import java.util.ArrayList;

public class Calculator {

    static float finalResult;

    static class Operations {

        static final char ADDITION_SYMBOL = '+';
        static final char SUBTRACTION_SYMBOL = '-';
        static final char MULTIPLICATION_SYMBOL = '*';
        static final char DIVISION_SYMBOL = '/';

        private Operations() {}

        public static String getSymbolsAsString() {
            return "" + ADDITION_SYMBOL + MULTIPLICATION_SYMBOL + DIVISION_SYMBOL + SUBTRACTION_SYMBOL;
        }
    }

    public static String Run(String expression) {
        return evaluateExpression(expression);
    }

    private static String evaluateExpression(String expression) {
        if (expression.charAt(0) == Operations.ADDITION_SYMBOL
                || expression.charAt(0) == Operations.SUBTRACTION_SYMBOL) {
            expression = 0 + expression;
        }

        String[] numbers = expression.split("[" + Operations.getSymbolsAsString() + "]");

        List<String> operationList = new ArrayList<>();
        for (int i = 0; i < expression.length() - 1; i++) {
            if (Operations.getSymbolsAsString().indexOf(expression.charAt(i)) >= 0) {
                operationList.add(String.valueOf(expression.charAt(i)));
            }
        }

        List<Float> numberList = new ArrayList<>();
        for (String number : numbers) {
            if (number.equals("-Infinity")) {
                numberList.add(Float.NEGATIVE_INFINITY);
            } else if (number.equals("Infinity")) {
                numberList.add(Float.POSITIVE_INFINITY);
            } else {
                try {
                    numberList.add(Float.parseFloat(number));
                } catch (Exception exc) {
                    return "ERROR";
                }
            }
        }

        Calculate(numberList, operationList);
        return Float.toString(finalResult);
    }

    private static void Calculate(List<Float> numbers, List<String> operations) {
        if (numbers.size() == 1) {
            finalResult = numbers.get(0);
            return;
        }

        float result = 0;
        int indexMultiply = operations.indexOf(String.valueOf(Operations.MULTIPLICATION_SYMBOL));
        int indexDivide = operations.indexOf(String.valueOf(Operations.DIVISION_SYMBOL));

        if (indexMultiply != -1 && (indexDivide == -1 || indexMultiply < indexDivide)) {
            result = numbers.get(indexMultiply) * numbers.get(indexMultiply + 1);
            numbers.set(indexMultiply, result);
            numbers.remove(indexMultiply + 1);
            operations.remove(indexMultiply);
            Calculate(numbers, operations);
            return;
        }

        if (indexDivide != -1) {
            result = numbers.get(indexDivide) / numbers.get(indexDivide + 1);
            numbers.set(indexDivide, result);
            numbers.remove(indexDivide + 1);
            operations.remove(indexDivide);
            Calculate(numbers, operations);
            return;
        }

        int indexPlus = operations.indexOf(String.valueOf(Operations.ADDITION_SYMBOL));
        int indexMinus = operations.indexOf(String.valueOf(Operations.SUBTRACTION_SYMBOL));

        if (indexPlus != -1 && (indexMinus == -1 || indexPlus < indexMinus)) {
            result = numbers.get(indexPlus) + numbers.get(indexPlus + 1);
            numbers.set(indexPlus, result);
            numbers.remove(indexPlus + 1);
            operations.remove(indexPlus);
            Calculate(numbers, operations);
            return;
        }

        if (indexMinus != -1) {
            result = numbers.get(indexMinus) - numbers.get(indexMinus + 1);
            numbers.set(indexMinus, result);
            numbers.remove(indexMinus + 1);
            operations.remove(indexMinus);
            Calculate(numbers, operations);
        }
    }
}
